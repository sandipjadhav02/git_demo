package com.upgrad.quora.api.controller;

import...
import com.google.common.net.MediaType;
import com.upgrad.quora.api.model.QuestionDetailsResponse;
import com.upgrad.quora.api.model.AnswerRequest;
import com.upgrad.quora.api.model.AnswerResponse;
import com.upgrad.quora.service.entity.AnswerEntity;
import com.upgrad.quora.service.error.ValidationErrors;
import com.upgrad.quora.service.exception.AuthorizationFailedException;
import com.upgrad.quora.service.exception.BadRequestException;
import com.upgrad.quora.service.exception.InvalidQuestionException;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;


@RestController
@RequestMapping ("/")

public class AnswerController {

    private AnswerController(AnswerService answerService){this.answerSwrvice = answerService;}

    @RequestMapping (path = "/question/{questionId}/answer/create}", method = RequestMethod.POST,
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<QuestionResponse> create(final QuestionRequest request, @RequestHeader("authorization") final String token)
            throws AuthorizationFailedException, BadRequestException {

        if (StringUtils.isBlank(request.getContent())) {
            throw new BadRequestException(ValidationErrors.NO_DETAIL_IN_QUESTION.getCode(),
                    ValidationErrors.NO_DETAIL_IN_QUESTION.getReason());
        }
        AnswerEntity answerEntity = new AnswerEntity(UUID.randomUUID().toString(), request.getContent(), LocalDateTime.now());
        AnswerEntity createdAnswer = answerService.create(answerEntity, token);
        QuestionResponse response = new QuestionResponse().id(createdAnswer.getUuid()).status("ANSWER CREATED");
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }
    @RequestMapping(path =  "/answer/edit/{answerId}", method = RequestMethod.PUT,
            produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<AnswerDetailsResponse>> getAll(@RequestHeader("AnswerEditRequest") final String token) throws AuthorizationFailedException {
        List<AnswerEntity> allAnswer = answerService.getAll(token);
        List<AnswerDetailsResponse> response = allAnswers.stream()
                .map(answer -> new AnswersResponse().id(answer.getUuid()).content(answer.getContent()))
                .collect(Collectors.toList());
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @RequestMapping(path = "/answer/delete/{answerId}", method = RequestMethod.DELETE,
            produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<QuestionResponse> delete(@PathVariable("answerId") String uuid,
                                                   @RequestHeader("authorization") final String token)
            throws AuthorizationFailedException, InvalidQuestionException {
        answerService.delete(uuid, token);
        AnswerResponse response = new AnswerResponse().id(uuid).status("ANSWER DELETED");
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @RequestMapping(path = "answer/all/{questionId}", method = RequestMethod.GET,
            produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<QuestionDetailsResponse>> getAll(@RequestHeader("authorization") final String token) throws AuthorizationFailedException {
        List<AnswerEntity> allAnswers = answerService.getAll(token);
        List<QuestionDetailsResponse> response = allQuestions.stream()
                .map(question -> new QuestionDetailsResponse().id(question.getUuid()).content(question.getContent()))
                .collect(Collectors.toList());
        return new ResponseEntity<>(response, HttpStatus.OK);
    }


}
